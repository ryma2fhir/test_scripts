## <code>{{page-title}}</code>
	
The specific procedure that is performed. Use text if the exact nature of the procedure cannot be coded (e.g. "Laparoscopic Appendectomy").

This element is sliced in UK Core to a SNOMED CT ValueSet {{pagelink:ValueSetUKCoreProcedureCode}} the slice is open so other ValueSets can be used.

---


