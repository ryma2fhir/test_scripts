## <code>{{page-title}}</code>

A reference to the ServiceRequest that initiated this encounter.

---


