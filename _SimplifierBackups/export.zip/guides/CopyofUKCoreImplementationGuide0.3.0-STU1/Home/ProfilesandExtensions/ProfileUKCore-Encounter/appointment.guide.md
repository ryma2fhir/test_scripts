## <code>{{page-title}}</code>

A reference to the appointment that scheduled this encounter. The resource being referenced should conform to the following:
- <a href="https://www.hl7.org/fhir/r4/appointment.html">Appointment Resource</a>

---

