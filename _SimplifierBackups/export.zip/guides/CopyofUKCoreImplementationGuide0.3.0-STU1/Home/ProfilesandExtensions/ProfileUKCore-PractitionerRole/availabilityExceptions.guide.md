## `availabilityExceptions`

Description of availability exceptions.


---

