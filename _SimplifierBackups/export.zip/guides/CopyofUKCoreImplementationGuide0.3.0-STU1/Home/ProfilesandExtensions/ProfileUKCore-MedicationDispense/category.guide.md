## `category`

Could be used for month-end finance reporting.

Routing (such as inpatient, outpatient pharmacy, homecare, community pharmacy etc) should be catered for within the initial `MedicationRequest`.

---
