## `address`

The address of the patient using the {{pagelink:Address3-duplicate-3}} datatype.

A patient may have multiple addresses with different uses or applicable periods.

---
