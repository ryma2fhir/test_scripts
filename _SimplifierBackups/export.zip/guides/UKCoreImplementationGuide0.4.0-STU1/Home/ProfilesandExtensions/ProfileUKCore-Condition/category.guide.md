## <code>{{page-title}}</code>

A category assigned to the condition.

This should be coded where possible using {{pagelink:ValueSetUKCore-ConditionCategory}}.

---