## `active`

Whether this practitioner's record is in active use

