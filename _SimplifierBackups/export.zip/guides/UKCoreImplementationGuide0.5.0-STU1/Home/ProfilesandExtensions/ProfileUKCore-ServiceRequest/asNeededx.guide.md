## <code>{{page-title}}</code>

If a CodeableConcept is present, it indicates the pre-condition for performing the service.

For the CodeableConcept, this element currently uses the FHIR example SNOMED CT Medication As Needed Reason Codes ValueSet consisting of the following SNOMED hierarchy, as no UK Core ValueSet has been defined:

<<404684003 (Clinical finding)

---
