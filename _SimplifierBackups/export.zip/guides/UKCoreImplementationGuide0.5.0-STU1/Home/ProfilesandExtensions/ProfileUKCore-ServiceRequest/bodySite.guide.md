## <code>{{page-title}}</code>

Anatomic location where the procedure should be performed.

This should be coded using SNOMED CT where possible using {{pagelink:ValueSetUKCore-BodySite-050}} if possible.

---
