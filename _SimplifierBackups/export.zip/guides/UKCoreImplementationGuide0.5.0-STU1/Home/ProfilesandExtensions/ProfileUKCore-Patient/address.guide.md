## `address`

The address of the patient using the {{pagelink:Address-050}} datatype.

A patient may have multiple addresses with different uses or applicable periods.

---
