## <code>{{page-title}}</code>

A collection of times that the Service Site is available.

- `availableTime.daysOfWeek`	Optional which days of the week are available between the start and end Times.
- `availableTime.allDay`	Optionally indicates if service always available e.g. 24 hour service.
- `availableTime.availableStartTime`	Optional opening time of day.
- `availableTime.availableEndTime`	Optional closing time of day.

---
