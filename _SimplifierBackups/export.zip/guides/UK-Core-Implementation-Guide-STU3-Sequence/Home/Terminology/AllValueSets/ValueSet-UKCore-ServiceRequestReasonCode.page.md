---
subject: https://fhir.hl7.org.uk/ValueSet/UKCore-ServiceRequestReasonCode
---
## UK Core Service Request Reason Code

{{page:Home/Terminology/AllValueSets/ValueSetTemplate.page.md}}