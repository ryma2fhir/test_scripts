---
subject: https://fhir.hl7.org.uk/ValueSet/UKCore-EmergencyCareDischargeStatus
---
## UK Core Emergency Care Discharge Status

{{page:Home/Terminology/AllValueSets/ValueSetTemplate.page.md}}