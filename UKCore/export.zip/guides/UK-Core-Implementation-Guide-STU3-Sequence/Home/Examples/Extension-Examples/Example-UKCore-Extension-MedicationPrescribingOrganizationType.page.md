---
subject: UKCore-Extension-MedicationPrescribingOrganizationType-Example
---
### An example to illustrate the type of organisation or setting responsible for authorising and issuing a medication, but not the organisation or setting delivering the patient care

{{page:Home/Examples/ExampleTemplate.page.md}}