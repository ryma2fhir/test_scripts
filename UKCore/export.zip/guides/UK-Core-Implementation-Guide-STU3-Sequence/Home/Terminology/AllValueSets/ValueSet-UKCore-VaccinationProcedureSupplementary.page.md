---
subject: https://fhir.hl7.org.uk/ValueSet/UKCore-VaccinationProcedureSupplementary
---
## UK Core Vaccination Procedure Supplementary

{{page:Home/Terminology/AllValueSets/ValueSetTemplate.page.md}}