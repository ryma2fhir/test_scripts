---
subject: https://fhir.hl7.org.uk/ValueSet/UKCore-QuestionnaireQuestionCodes
---
## UK Core Questionnaire Question Codes

{{page:Home/Terminology/AllValueSets/ValueSetTemplate.page.md}}