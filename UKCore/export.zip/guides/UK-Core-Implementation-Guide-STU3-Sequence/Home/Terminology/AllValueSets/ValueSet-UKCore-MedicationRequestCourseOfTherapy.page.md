---
subject: https://fhir.hl7.org.uk/ValueSet/UKCore-MedicationRequestCourseOfTherapy
---
## UK Core Medication Request Course Of Therapy

{{page:Home/Terminology/AllValueSets/ValueSetTemplate.page.md}}