---
subject: https://fhir.hl7.org.uk/ValueSet/UKCore-LegalStatusClassification
---
## UK Core Legal Status Classification

{{page:Home/Terminology/AllValueSets/ValueSetTemplate.page.md}}