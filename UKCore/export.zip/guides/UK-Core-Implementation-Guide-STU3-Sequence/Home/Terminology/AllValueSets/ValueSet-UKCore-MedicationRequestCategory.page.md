---
subject: https://fhir.hl7.org.uk/ValueSet/UKCore-MedicationRequestCategory
---
## UK Core Medication Request Category

{{page:Home/Terminology/AllValueSets/ValueSetTemplate.page.md}}