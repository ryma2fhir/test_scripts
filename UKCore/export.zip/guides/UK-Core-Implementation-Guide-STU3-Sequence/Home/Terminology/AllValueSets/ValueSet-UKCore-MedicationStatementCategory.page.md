---
subject: https://fhir.hl7.org.uk/ValueSet/UKCore-MedicationStatementCategory
---
## UK Core Medication Statement Category

{{page:Home/Terminology/AllValueSets/ValueSetTemplate.page.md}}