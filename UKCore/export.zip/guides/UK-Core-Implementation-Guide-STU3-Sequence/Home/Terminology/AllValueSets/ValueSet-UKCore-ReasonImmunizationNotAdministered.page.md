---
subject: https://fhir.hl7.org.uk/ValueSet/UKCore-ReasonImmunizationNotAdministered
---
## UK Core Reason Immunization Not Administered

{{page:Home/Terminology/AllValueSets/ValueSetTemplate.page.md}}