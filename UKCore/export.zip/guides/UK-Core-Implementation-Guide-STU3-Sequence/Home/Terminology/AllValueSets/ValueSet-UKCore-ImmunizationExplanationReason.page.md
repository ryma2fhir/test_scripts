---
subject: https://fhir.hl7.org.uk/ValueSet/UKCore-ImmunizationExplanationReason
---
## UK Core Immunization Explanation Reason

{{page:Home/Terminology/AllValueSets/ValueSetTemplate.page.md}}