---
subject: https://fhir.hl7.org.uk/ValueSet/UKCore-PersonMaritalStatusCode
---
## UK Core Person Marital Status Code

{{page:Home/Terminology/AllValueSets/ValueSetTemplate.page.md}}