---
subject: https://fhir.hl7.org.uk/ValueSet/UKCore-NHSNumberVerificationStatus
---
## UK Core NHS Number Verification Status


{{page:Home/Terminology/AllValueSets/ValueSetTemplate.page.md}}