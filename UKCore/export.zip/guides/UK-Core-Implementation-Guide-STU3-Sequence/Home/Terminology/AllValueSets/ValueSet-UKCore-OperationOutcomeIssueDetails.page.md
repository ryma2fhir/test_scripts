---
subject: https://fhir.hl7.org.uk/ValueSet/UKCore-OperationOutcomeIssueDetails
---
## UK Core Operation Outcome Issue Details

{{page:Home/Terminology/AllValueSets/ValueSetTemplate.page.md}}