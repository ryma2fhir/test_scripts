---
subject: https://fhir.hl7.org.uk/ValueSet/UKCore-DeathNotificationStatus
---
## UK Core Death Notification Status

{{page:Home/Terminology/AllValueSets/ValueSetTemplate.page.md}}