---
subject: https://fhir.hl7.org.uk/ValueSet/UKCore-MedicationAdministrationCategory
---
## UK Core Medication Administration Category

{{page:Home/Terminology/AllValueSets/ValueSetTemplate.page.md}}