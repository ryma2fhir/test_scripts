---
subject: https://fhir.hl7.org.uk/ValueSet/UKCore-ImmunizationAdministrationBodySite
---
## UK Core Immunization Administration Body Site

{{page:Home/Terminology/AllValueSets/ValueSetTemplate.page.md}}