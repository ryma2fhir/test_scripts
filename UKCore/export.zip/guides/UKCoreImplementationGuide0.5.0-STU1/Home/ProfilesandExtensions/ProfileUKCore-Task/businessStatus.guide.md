## <code>{{page-title}}</code>
	
Contains business-specific nuances of the business state.

No ValueSet binding has been specified in either the FHIR standard or the UK Core.

---
