## <code>{{page-title}}</code>

A reference to the appointment that scheduled this encounter. The resource being referenced should conform to the following:
- {{pagelink:Profile-Appointment-90f31814-417d-46fa-8ae3-bec132f819e8}}

---

