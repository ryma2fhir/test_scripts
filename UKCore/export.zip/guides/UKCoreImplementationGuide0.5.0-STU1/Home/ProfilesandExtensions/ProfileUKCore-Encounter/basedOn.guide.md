## <code>{{page-title}}</code>

A reference to the `ServiceRequest` that initiated this encounter. The resource being referenced should conform to the following:

- {{pagelink:Profile-ServiceRequest-6b7f601e-1517-4596-8a8e-0f8f40caa095}}

---


