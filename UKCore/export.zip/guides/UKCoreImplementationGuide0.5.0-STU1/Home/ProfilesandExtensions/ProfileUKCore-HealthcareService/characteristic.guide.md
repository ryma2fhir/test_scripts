## <code>{{page-title}}</code>

Collection of attributes e.g. is wheelchair accessible.

This element is not currently bound to any FHIR or UK Core ValueSet.

---
