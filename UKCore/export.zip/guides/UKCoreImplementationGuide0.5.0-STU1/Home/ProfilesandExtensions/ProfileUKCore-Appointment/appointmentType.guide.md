## <code>{{page-title}}</code>

The style of appointment or patient that has been booked in the slot (not service type).

This should be from {{pagelink:ValueSetUKCore-AppointmentReasonCode-050}} if possible.

---
