## <code>{{page-title}}</code>

Anatomical location, if relevant. Only used if not implicit in code found in `Condition.code`.

This should be coded using SNOMED CT where possible using {{pagelink:ValueSetUKCore-BodySite-050}}.

---
