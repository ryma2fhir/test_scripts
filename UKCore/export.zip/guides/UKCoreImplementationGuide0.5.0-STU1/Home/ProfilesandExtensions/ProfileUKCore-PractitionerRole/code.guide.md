## `code`

A code represeenting the role of the practitioner.

Use a code from {{pagelink:ValueSetUKCore-PractitionerRoleCode-050}}.

Where a value required is not present an alternative CodeSystem may be used.

---



