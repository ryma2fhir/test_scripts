## <code>{{page-title}}</code>

This flag is used to mark the record to not be used. Assumed to be active if no value is provided for the active element.

This element is labelled as a modifier because it may be used to mark that the resource was created in error.

---
