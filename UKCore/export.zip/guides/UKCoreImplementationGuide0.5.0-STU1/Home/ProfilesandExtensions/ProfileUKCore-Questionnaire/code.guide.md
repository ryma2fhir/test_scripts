## <code>{{page-title}}</code>

An identifier for this question or group of questions in a particular terminology.

This element currently uses {{pagelink:ValueSetUKCore-QuestionnaireQuestionCodes-050}} consisting of any concept from SNOMED. This set of codes may not necessarily be complete or appropriate and may require further discussion in the future.