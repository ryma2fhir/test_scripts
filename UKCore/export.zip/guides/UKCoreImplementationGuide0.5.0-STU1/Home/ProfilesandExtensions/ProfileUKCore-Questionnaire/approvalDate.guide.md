## <code>{{page-title}}</code>

The date on which the resource content was approved by the publisher.

---
