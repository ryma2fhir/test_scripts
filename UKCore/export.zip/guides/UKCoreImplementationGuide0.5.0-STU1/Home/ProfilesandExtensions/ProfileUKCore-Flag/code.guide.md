## <code>{{page-title}}</code>

The coded value or textual component of the flag to display to the user.

This element currently uses the FHIR example Flag Code ValueSet consisting of the following SNOMED hierarchy, as no UK Core ValueSet has been defined:

<<404684003 (Clinical finding)

---
