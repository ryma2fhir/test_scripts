## <code>{{page-title}}</code>
	
Detailed and structured anatomical location information. Multiple locations are allowed - e.g. multiple punch biopsies of a lesion.

This element should be coded using SNOMED CT where possible using {{pagelink:ValueSetUKCore-BodySite-050}}.

---

