## <code>{{page-title}}</code>
A request for this procedure. The resource being referenced should conform to the following:	
- <a href="https://simplifier.net/hl7fhirukcorer4/ukcorecareplan">UKCore-CarePlan Profile</a>
- {{pagelink:Profile-ServiceRequest-6b7f601e-1517-4596-8a8e-0f8f40caa095}}

---

