## `birthDate`

The practitioner's date of birth.

---
