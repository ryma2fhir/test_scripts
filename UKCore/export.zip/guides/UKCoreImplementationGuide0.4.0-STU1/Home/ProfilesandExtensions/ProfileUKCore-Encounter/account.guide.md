## <code>{{page-title}}</code>

The set of accounts that may be used for billing for this Encounter. The resource being referenced should conform to the following:
<a href="https://www.hl7.org/fhir/r4/account.html">Account Resource</a>.

---

