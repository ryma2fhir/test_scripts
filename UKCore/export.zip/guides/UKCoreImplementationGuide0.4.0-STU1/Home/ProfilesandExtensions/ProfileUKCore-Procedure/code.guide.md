## <code>{{page-title}}</code>
	
The specific procedure that is performed. Use text if the exact nature of the procedure cannot be coded (e.g. "Laparoscopic Appendectomy").

This element should be coded using SNOMED CT where possible using {{pagelink:ValueSetUKCore-ProcedureCode}}.

---


