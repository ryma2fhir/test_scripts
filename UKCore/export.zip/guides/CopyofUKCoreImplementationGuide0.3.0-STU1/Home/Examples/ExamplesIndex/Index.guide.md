---
topic: Library-Examples-3bc726b2-ddb5-43b1-806f-55e38d70183c
---
## Examples

<div markdown="span" class="alert alert-warning" role="alert"><i class="fa fa-information"></i><h4> Examples Usage note: </h4>Whilst every effort has been made to ensure that the examples are correct and useful, they are not a normative part of the specification.</div>

---





