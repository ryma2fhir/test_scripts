---
topic: Home-Downloads-15ba699d-87f6-4e83-9e54-5b763c0744e2
---
## Downloads

<table id="assets">
<tr>
<th>Description</th>
<th>Status</th>
<th>Link</th>
</tr>
<tr>
<td>Release package for UK Core 0.3.0 - STU1 </td>
<td>Active</td>
<td><a href="https://simplifier.net/packages/ukcore.release1/1.0.1">ukcore.release1.stu1.01.01</a></td>
</tr>
<tr>
<td>Inital development package</td>
<td>Retired</td>
<td><a href="https://simplifier.net/packages/ukcore.r4.stu.02.00.00/2.0.0">ukcore.r4.stu.02.00.00/2.0.0</a></td>
</tr>
</table>

---


