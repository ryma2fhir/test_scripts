## <code>{{page-title}}</code>

A reference to the `ServiceRequest` that initiated this encounter. The resource being referenced should conform to the following:
- <a href="https://simplifier.net/hl7fhirukcorer4/ukcoreservicerequest">UKCore-ServiceRequest Profile</a>


---


