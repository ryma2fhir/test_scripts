## `category`

The value set has been extended with `leave` and `discharge` to align with the equivlant value set used by `medicationRequest`. 

---
