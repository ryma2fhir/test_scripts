## `availableTime`

A collection of times the practitioner is available or performing the role(s) at the location.

---

