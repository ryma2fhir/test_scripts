## `active`

Whether this practitioner role record is in active use.

---
