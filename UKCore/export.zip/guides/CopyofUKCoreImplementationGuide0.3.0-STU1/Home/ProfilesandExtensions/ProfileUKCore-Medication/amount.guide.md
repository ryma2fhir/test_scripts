## `amount`
Optional.

---
