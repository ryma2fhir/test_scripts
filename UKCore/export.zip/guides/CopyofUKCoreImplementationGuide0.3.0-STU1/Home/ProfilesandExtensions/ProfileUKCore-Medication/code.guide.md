## `code` (Mandatory)

All medication must be represented using the NHS dm+d terminology.

- The `code.coding.system` must be `https://dmd.nhs.uk/`.
- The `code.coding.code` must be the NHS dm+d concept code.
- The `code.coding.display` must be the NHS dm+d concept description.

---