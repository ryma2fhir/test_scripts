## <code>{{page-title}}</code>
A request for this procedure. The resource being referenced should conform to the following:	
- <a href="https://simplifier.net/hl7fhirukcorer4/ukcorecareplan">UKCore-CarePlan Profile</a>
- <a href="https://simplifier.net/hl7fhirukcorer4/ukcoreservicerequest">UKCore-ServiceRequest Profile</a>


---

