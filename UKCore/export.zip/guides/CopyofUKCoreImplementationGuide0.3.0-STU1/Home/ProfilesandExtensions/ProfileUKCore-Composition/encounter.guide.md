## <code>{{page-title}}</code>
Describes the clinical encounter or type of care this documentation is associated with using a reference. The resource being referenced should conform to 
- {{pagelink:Profile-Encounter-5a2f9b8c-ab14-4c75-b214-1da4cdf34cd4}}


---