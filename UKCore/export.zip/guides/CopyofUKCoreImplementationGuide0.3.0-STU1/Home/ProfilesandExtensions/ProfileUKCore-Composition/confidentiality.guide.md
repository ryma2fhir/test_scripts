## <code>{{page-title}}</code>
The code specifying the level of confidentiality of the Composition. 	
The exact use of this element, and enforcement and issues related to highly sensitive documents are out of scope for this specification, and delegated to implementation profiles (see security section). This element is labelled as a modifier because highly confidential documents must not be treated as if they are not. As there is currently no national agreement on the use of this element it is not recommended for use in the UK.

---