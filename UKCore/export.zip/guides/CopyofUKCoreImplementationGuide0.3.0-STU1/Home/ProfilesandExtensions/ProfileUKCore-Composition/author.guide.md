## <code>{{page-title}}</code>

	
Identifies who is responsible for the information in the composition, not necessarily who typed it in. This element MUST be present.

---
