## <code>{{page-title}}</code>

The composition editing time, when the composition was last logically changed by the author. This element MUST be present.

---