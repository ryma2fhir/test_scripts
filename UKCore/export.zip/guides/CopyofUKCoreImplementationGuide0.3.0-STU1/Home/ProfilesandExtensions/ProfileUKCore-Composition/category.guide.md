## <code>{{page-title}}</code>

A categorization for the type of the composition - helps for indexing and searching. This may be implied by or derived from the code specified in the Composition Type. A binding to a ValueSet containing a set of SNOMED concepts has been suggested as a starting point for the UK Core (hence the "Preferred" binding strength): {{pagelink:ValueSetUKCore-CompositionCategory-030}}.

---