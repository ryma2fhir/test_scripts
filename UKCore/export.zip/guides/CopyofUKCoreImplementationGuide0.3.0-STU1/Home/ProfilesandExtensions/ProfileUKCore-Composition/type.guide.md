## <code>{{page-title}}</code>

The type of document which MUST be present and should use a value from {{pagelink:ValueSetUKCore-DocumentType-030}}.

---