## `category`
Optional.

Defines the care setting for the administration. The preferred value set contains `inpatient`, `outpatient` and `community`.

---
