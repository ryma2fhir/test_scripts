## `alias`

A list of alternate names that the organisation is known as, or was known as in the past.