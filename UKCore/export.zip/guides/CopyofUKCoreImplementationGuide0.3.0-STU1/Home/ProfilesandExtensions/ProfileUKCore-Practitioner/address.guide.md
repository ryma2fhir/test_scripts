## `address`

The address of the Practitioner using the {{pagelink:Address-030}} datatype.

---