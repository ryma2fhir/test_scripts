## <code>{{page-title}}</code>
The source of the decision. The referenced resource should conform to one of the following:

* {{pagelink:Profile-Practitioner-96448d2b-cd33-42cb-b1db-f48ae31db401}}
* {{pagelink:Profile-PractitionerRole-91e0c0ae-8b79-41de-b8e1-4eeb30ab2565}}


---

