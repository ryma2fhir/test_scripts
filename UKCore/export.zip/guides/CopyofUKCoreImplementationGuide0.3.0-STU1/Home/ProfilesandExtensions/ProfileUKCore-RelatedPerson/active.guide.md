## <code>{{page-title}}</code>
Whether this related person's record is in active use.

---
