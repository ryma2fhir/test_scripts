## `encounter`

A reference to the encounter resource which should conform to  {{pagelink:Profile-Encounter-5a2f9b8c-ab14-4c75-b214-1da4cdf34cd4}}.

Implementation guidance is pending further analysis for the potential use of this element.

---
