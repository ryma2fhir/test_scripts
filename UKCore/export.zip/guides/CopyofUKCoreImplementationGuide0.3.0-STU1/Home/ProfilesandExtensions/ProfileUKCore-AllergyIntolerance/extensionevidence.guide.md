## {{page-title}}

{{pagelink:ExtensionUKCore-Evidence-030}} to reference a `DiagnosticReport` resource for investigations that confirm the certainty of the allergy or intolerance diagnosis.


---
