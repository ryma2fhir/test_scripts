## <code>{{page-title}}</code>

Clinical stage or grade of a condition. May include formal severity assessments.

---