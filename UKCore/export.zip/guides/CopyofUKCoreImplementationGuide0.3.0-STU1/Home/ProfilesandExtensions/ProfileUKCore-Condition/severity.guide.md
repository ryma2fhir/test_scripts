## <code>{{page-title}}</code>

A subjective assessment of the severity of the condition as evaluated by the clinician.

---