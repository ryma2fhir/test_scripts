## <code>{{page-title}}</code>

Encounter created as part of. The resource being referenced should conform to the following:  
- {{pagelink:Profile-Encounter-5a2f9b8c-ab14-4c75-b214-1da4cdf34cd4}}

---