## `birthDate`

The patient's date of birth. An approximate date may be used (e.g. just the year) where the full date is not known.

birthDate includes an extension {{pagelink:commonextensionpatient-birthTime-030}} This should be included when the birth time is relevant.

---
