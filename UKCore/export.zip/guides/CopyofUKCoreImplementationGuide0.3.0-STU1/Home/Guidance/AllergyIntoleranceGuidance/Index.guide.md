---
topic: Guidance-Allergy-544dbad8-07e7-4a45-9f1c-ae7be7ae6a5f
---
## AllergyIntolerance Guidance

The recording of allergy and intolerance information in patient records is a major component of communicating the effects of external substances and compounds on patient health.

---
