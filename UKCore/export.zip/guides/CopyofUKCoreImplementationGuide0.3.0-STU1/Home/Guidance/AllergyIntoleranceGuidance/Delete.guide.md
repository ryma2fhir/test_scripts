## {{page-title}}

Out of scope for this version of UK Core.
<!--Once created and made available to query or added to a shared record, deleting instances of the `AllergyIntolerence` resource should be avoided wherever possible.

If the recorded allergy resource was created in error, update the resource and set the `verificationStatus` to `entered-in-error`.

Otherwise refer to the guidance above for **Update**.-->

---
