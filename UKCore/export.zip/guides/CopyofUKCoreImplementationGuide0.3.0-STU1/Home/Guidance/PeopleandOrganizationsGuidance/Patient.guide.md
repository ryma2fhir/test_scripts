## `Patient`

This profile relates to the Patient receiving care. Guidance relating to Patients may be found on the {{pagelink:Profile-Patient-fa365b29-79b9-4024-9b49-729ac15e401c}} page.

---