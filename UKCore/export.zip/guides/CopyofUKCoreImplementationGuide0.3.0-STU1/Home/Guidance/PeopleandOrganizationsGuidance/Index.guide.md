---
topic: Guidance-People-29e2a34a-9f2c-4272-8f9b-d64aeb920acc
---
## People and Organizations

This set of Profiles relate to the `Patient` receiving care, the `Practitioner` (health and care professional) providing care, their `PractionerRole`, the `Organization` responsible for delivering care and the `Location` at which care is delivered.
 
There are other FHIR Resources related to people not currently covered in this guidance, they are:
 
- `RelatedPerson` 
- `Person` 
- `Group`.
 

---
 


 