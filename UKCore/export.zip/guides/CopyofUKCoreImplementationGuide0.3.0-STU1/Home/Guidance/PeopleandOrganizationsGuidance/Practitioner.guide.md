## `Practitioner`

This profile relates to health and care professional practitioners delivering care. 

Guidance relating to Practitioners may be found on the {{pagelink:Profile-Practitioner-96448d2b-cd33-42cb-b1db-f48ae31db401}} page. 

---