## 

Whether the organization's record is still in active use

---
