## <code>{{page-title}}</code>

The address of the related pers using the {{pagelink:Address-110}} datatype.

---


