## <code>{{page-title}}</code>

A reference to the appointment that scheduled this encounter.

---

