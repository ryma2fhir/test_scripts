## <code>{{page-title}}</code>

A categorization for the type of the composition - helps for indexing and searching. This may be implied by or derived from the code specified in the Composition Type. Further investgation is required about the usage of this element for UK Core.

---