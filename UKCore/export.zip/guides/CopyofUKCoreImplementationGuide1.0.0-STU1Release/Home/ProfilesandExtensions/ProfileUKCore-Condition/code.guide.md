## <code>{{page-title}}</code>

Identification of the condition, problem or diagnosis.

This should be coded using SNOMED CT where possible using the {{pagelink:ValueSetUKCoreConditionCode-110}}

---