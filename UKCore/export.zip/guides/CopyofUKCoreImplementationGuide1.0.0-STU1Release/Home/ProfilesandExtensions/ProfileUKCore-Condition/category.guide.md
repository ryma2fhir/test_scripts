## <code>{{page-title}}</code>

A category assigned to the condition.

Further discussion and guidance is required on use of this element.

---