## `code`

A code represeenting the role of the practitioner.

Use a code from {{pagelink:ValueSetUKCorePractitionerRoleCode}}.

Where a value required is not present an alternative CodeSystem may be used.

---



