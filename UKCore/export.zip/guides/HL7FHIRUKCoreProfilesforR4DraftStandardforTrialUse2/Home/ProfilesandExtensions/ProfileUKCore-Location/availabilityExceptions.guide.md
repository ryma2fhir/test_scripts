## `availabilityExceptions`
A description, as a text string, of when the locations opening hours are different to normal, e.g. public holiday availability. Succinctly describing all possible exceptions to normal site availability as detailed in hoursOfOperation.

e.g. "closed bank holidays".

---