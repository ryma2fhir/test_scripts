## `address`

The address of the location using the {{pagelink:Address3-duplicate-3}} datatype.


---
