## birthDate

Birthdate of the practitioner