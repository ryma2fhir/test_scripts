## `active`

Whether this practitioners's record is in active use.

---