## `address`

The address of the Practitioner using the {{pagelink:Address3-duplicate-3}} datatype.

---