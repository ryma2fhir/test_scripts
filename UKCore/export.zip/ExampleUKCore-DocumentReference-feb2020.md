### Example UKCore-DocumentReference

{{xml:UKCore-DocumentReference-example}}